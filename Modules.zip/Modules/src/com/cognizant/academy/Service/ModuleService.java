package com.cognizant.academy.Service;

import java.util.List;

import com.cognizant.academy.Model.Course;
import com.cognizant.academy.Model.Module;
import com.cognizant.academy.Model.ObjectiveJsp;

public interface ModuleService {
	
	public List<String> getModule_list(String course_id);
	
	public void addModule(Module module, int course_id);
	
	public List<String> getStack_list();
	
	public List<ObjectiveJsp> fetchobj(String name);
	
	public List<String> fetchObjective_names(String stack);
	
	public void addObjective(String module, String objective);
	
	public void removeObjective(String s);
	
	public void createTables();
	
	public Course getCourseName(String course_id);
	
	public List<String> check_Modname(String name);

}
