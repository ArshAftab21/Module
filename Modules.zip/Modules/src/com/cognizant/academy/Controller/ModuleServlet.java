package com.cognizant.academy.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.academy.Model.Module;
import com.cognizant.academy.Model.Module_Bo;
import com.cognizant.academy.Model.Objective;
import com.cognizant.academy.Model.ObjectiveJsp;
import com.google.gson.Gson;

public class ModuleServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    
    public ModuleServlet() 
    {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("doGet");
		//Module_Bo bo=new Module_Bo();
		//bo.createTables();
		String act=request.getParameter("act");
		if(act!=null)
		{
			if(act.equals("getModules"))
			{
				getModuleList(request, response);
			}
			if(act.equals("stacklist"))
			{
				getStackList(request,response);
			}
			if(act.equals("objList"))
			{
				getObjectiveList(request,response);
			}
			if(act.equals("fetchModuleObj"))
			{
				fetchModuleobj(request,response);
			}
			if(act.equals("fetchModuleObjreload"))
			{
				fetchModuleobjReloading(request,response);
			}
		
		}
		
	}

	
	private void fetchModuleobjReloading(HttpServletRequest request, HttpServletResponse response) throws IOException 
	{
		System.out.println("Inside");
		HttpSession session=request.getSession();
	     String Mod_name=(String) session.getAttribute("Mod");	         
	        Module_Bo bo=new Module_Bo();
	        List<ObjectiveJsp> olist=bo.fetchobj(Mod_name);
	        String json=new Gson().toJson(olist);
			System.out.println(json);
			response.setContentType("application/json");
			
			response.getWriter().write(json);
			response.getWriter().flush();

		
	}


	private void getStackList(HttpServletRequest request, HttpServletResponse response) throws IOException 
	{
		Module_Bo bo=new Module_Bo();
		 List<String> slist=bo.getStack_list();
		 String json=new Gson().toJson(slist);
			System.out.println(json);
			response.setContentType("application/json");
			
			response.getWriter().write(json);
			response.getWriter().flush();
	       
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("DoPost");
		String act=request.getParameter("act");
		if(act!=null)
		{
			
			if(act.equals("addModule"))
			{
				addModule(request,response);
			}
			
			if(act.equals("addObjective"))
			{
				addObjective(request,response);
			}
			if(act.equals("deleteObj"))
			{
				deleteObjective(request,response);
			}
			
		}
	}


	private void fetchModuleobj(HttpServletRequest request, HttpServletResponse response) throws IOException 
	{
		  //fetching list of objectives for selected module to display on table
		System.out.println("Inside");
		HttpSession session=request.getSession();
	     String Mod_name=request.getParameter("module");
	     System.out.println(Mod_name);
	       
	        session.setAttribute("Mod", Mod_name);
	        
	        
	         
	        Module_Bo bo=new Module_Bo();
	        List<ObjectiveJsp> olist=bo.fetchobj(Mod_name);
	        String json=new Gson().toJson(olist);
			System.out.println(json);
			response.setContentType("application/json");
			
			response.getWriter().write(json);
			response.getWriter().flush();

		
	}


	private void deleteObjective(HttpServletRequest request, HttpServletResponse response) 
	{
		//Method to delete selected objectives from a module
		 String[] names = request.getParameterValues("chk1");
		
		 Module_Bo bo=new Module_Bo(); 
		  for(String s:names)
		  {
			  System.out.println(s);
			 bo.removeObjective(s);
		  }
		  getModuleList(request, response);
		
	}


	private void addObjective(HttpServletRequest request, HttpServletResponse response) 
	{
		//Method to add objective to the selected Module
		HttpSession session=request.getSession();
		String Mod_name=(String) session.getAttribute("Mod");
		System.out.println(Mod_name);
		String Objective=request.getParameter("objective");
		Module_Bo bo=new Module_Bo(); 
		bo.addObjective(Mod_name,Objective);
		getModuleList(request, response);
		
	}


	private void getObjectiveList(HttpServletRequest request, HttpServletResponse response) throws IOException 
	{
		//Method to fetch list of objective for selected stack
		String stack=request.getParameter("stack_name");
		Module_Bo modulebo=new Module_Bo();
	    List<String> olist=modulebo.fetchObjective_names(stack);
	    String json=new Gson().toJson(olist);
		System.out.println(json);
		response.setContentType("application/json");
		
		response.getWriter().write(json);
		response.getWriter().flush();
		
	}


	private void addModule(HttpServletRequest request, HttpServletResponse response) 
	{
		//method to add the module to the selected course
		HttpSession session=request.getSession();
		String c=(String)session.getAttribute("Mod_course");
		int course_id=Integer.parseInt(c);
		Module module=new Module();
        String name=request.getParameter("name");        
        module.setName(name);
        Module_Bo modulebo=new Module_Bo();
        modulebo.addModule(module,course_id);
        getModuleList(request,response);
		
	}


	private void getModuleList(HttpServletRequest request, HttpServletResponse response) //Sort of parent method since its called every time page is loaded
	{
		//Session to manage module page for each time a course request comes in
		HttpSession session=request.getSession();
		String course_id="1";
		if(course_id.equalsIgnoreCase((String)session.getAttribute("Mod_course")))
		{
		}
		else
		{
			session.removeAttribute("Mod");
			session.setAttribute("Mod",null);
		}
		session.setAttribute("Mod_course",course_id);
		
		//Fetching Module list for course_id
		 Module_Bo bo=new Module_Bo();        
	     List<String> mlist=bo.getModule_list(course_id);
	     request.setAttribute("ModList",mlist);
	     String modhead = null;
	    
	     modhead=(String) session.getAttribute("Mod");
	     
	     if(modhead==null)
	     {
	    	 request.setAttribute("Modhead","Select Module");
	     }
	     else
	     {
	    	 request.setAttribute("Modhead",modhead);
	     }

	        
	        //redirecting to modules.jsp page
	        RequestDispatcher dis=request.getRequestDispatcher("WEB-INF/View/Modules.jsp");
	        try 
	        {
				dis.forward(request, response);
			} 
	        catch (ServletException e) 
	        {
				
				e.printStackTrace();
			} 
	        catch (IOException e) 
	        {
				
				e.printStackTrace();
			}
		
	}

}
