package com.cognizant.academy.Model;

public class ObjectiveJsp 
{
private 
int id;
String name;
String stack_name;
int duration;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getStack_name() {
	return stack_name;
}
public void setStack_name(String stack_name) {
	this.stack_name = stack_name;
}
public int getDuration() {
	return duration;
}
public void setDuration(int duration) {
	this.duration = duration;
}

}
