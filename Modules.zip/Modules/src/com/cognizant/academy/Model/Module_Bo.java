package com.cognizant.academy.Model;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.academy.Model.Objective;
import com.cognizant.academy.Dao.Module_Dao;


public class Module_Bo {

	public List<String> getModule_list(String course_id) //getiing list of module and returning list of module name
	{
		Module_Dao dao=new Module_Dao();
		List<Module> modlist=dao.getmodlist(course_id);
		List<String> list=new ArrayList<String>();
		for(Module m:modlist)
		{
			list.add(m.getName());
		}
		return list;
	}
	
	
	public void addModule(Module module, int course_id) 
	{
		Module_Dao dao=new Module_Dao();
		Course c=dao.getCourse(course_id);
		module.setCourse(c);
		  dao.add(module);
          
	}
	
	
	public List<String> getStack_list() 
	{
		Module_Dao dao=new Module_Dao();
		List<Stack> stackList=dao.getStacklist();
		List<String> list=new ArrayList<String>();
		for(Stack s:stackList)
		{
			list.add(s.getName());
		}
		return list;
	}
	
	
	public List<ObjectiveJsp> fetchobj(String name) 
	{
		Module_Dao dao=new Module_Dao();
		int mod_id=dao.getModule_id(name.trim());
		System.out.println(mod_id);
		List<Objective> objList=dao.getModuleObjectives(mod_id);
		List<ObjectiveJsp> list=new ArrayList<ObjectiveJsp>();
		for(Objective o: objList)
		{
			ObjectiveJsp oj=new ObjectiveJsp();
			oj.setId(o.getId());
			oj.setName(o.getName());
			oj.setStack_name(o.getStack().getName());
			oj.setDuration(o.getDuration());
			list.add(oj);
		}
		return list;
	}
	
	
	public List<String> fetchObjective_names(String stack) 
	{
		
		Module_Dao dao=new Module_Dao();
		int stack_id=dao.getStack_id(stack);
		System.out.println("stack"+stack_id); 
		List<Objective> objList=dao.getStackObjectives(stack_id);
		System.out.println(objList);
		List<String> list=new ArrayList<String>();
		for(Objective o:objList)
		{
			list.add(o.getName());
		}
		return list;	
	}


	public void addObjective(String module,String objective) 
	{
		
		Module_Dao dao=new Module_Dao();
		int mod_id=dao.getModule_id(module.trim());
		int obj_id=dao.getObjective_id(objective);
		dao.addObjectiveToModule(mod_id,obj_id);
         
	}


	public void removeObjective(String s) 
	{
		
		Module_Dao dao=new Module_Dao();
		int obj_id=dao.getObjective_id(s.trim());
		 dao.removeObjective(obj_id);
	}


	public void createTables() 
	{
		Module_Dao dao=new Module_Dao();
		Course c=new Course();
		c.setName("Web Development");
		dao.insertCourse(c);
		
		Module m=new Module();
		m.setName("Arsh");
		m.setCourse(c);
		dao.insertModule(m);
		
		Module m1=new Module();
		m1.setName("Aftab");
		m1.setCourse(c);
		dao.insertModule(m1);
		
		Stack s=new Stack();
		s.setName("HTML");
		dao.insertStack(s);
		
		Stack s1=new Stack();
		s1.setName("Css");
		dao.insertStack(s1);
		
		Objective o1=new Objective();
		o1.setName("obj1");
		o1.setDuration(150);
		o1.setModule(null);
		o1.setStack(s);
		dao.insertObj(o1);
		
		Objective o2=new Objective();
		o2.setName("obj2");
		o2.setDuration(120);
		o2.setModule(null);
		o2.setStack(s);
		dao.insertObj(o2);
		
		Objective o3=new Objective();
		o3.setName("obj3");
		o3.setDuration(100);
		o3.setModule(null);
		o3.setStack(s1);
		dao.insertObj(o3);
		
		Objective o4=new Objective();
		o4.setName("obj4");
		o4.setDuration(90);
		o4.setModule(null);
		o4.setStack(s1);
		dao.insertObj(o4);

	}


}
