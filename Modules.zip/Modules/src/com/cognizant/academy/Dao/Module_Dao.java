package com.cognizant.academy.Dao;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import com.cognizant.academy.Model.Course;
import com.cognizant.academy.Model.Module;
import com.cognizant.academy.Model.Objective;
import com.cognizant.academy.Model.Stack;
import com.cognizant.academy.utils.AppBaseDao;


public class Module_Dao extends AppBaseDao {
	
	
	public List<Module> getmodlist(String course_id) 
	{
		List<Module> list=new ArrayList<Module>();
		int course=Integer.parseInt(course_id);
		try 
		{
			em=getEntityManager();
			em.getTransaction().begin();
			Query query=em.createQuery("from Module where course_id='"+course+"'");
			list=(List<Module>)query.getResultList();
			em.getTransaction().commit();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			closeEntityManager();
		}
		return list;
		
	}

	
	
public void add(Module obj) 
	{
       
        try
        {
        	em=getEntityManager();
			em.getTransaction().begin();
            em.persist(obj);
            em.getTransaction().commit();
        }
        catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			closeEntityManager();
		}
        
   }


 public List<Stack> getStacklist() 
 {
	
	List<Stack> list=new ArrayList<Stack>();
	try 
	{
		em=getEntityManager();
		em.getTransaction().begin();
		Query query=em.createQuery("from Stack");
		list=(List<Stack>)query.getResultList();
		em.getTransaction().commit();
	} 
	  catch (Exception e) 
			{
				e.printStackTrace();
			} 
			finally 
			{
				closeEntityManager();
			}
	return list;
}



public List<Objective> getModuleObjectives(int mod_id) 
{
	
	List<Objective> list=new ArrayList<Objective>();
	try 
	{
		em=getEntityManager();
		em.getTransaction().begin();
		Query query=em.createQuery("from Objective where module_id='"+mod_id+"'");
		list=(List<Objective>)query.getResultList();
		em.getTransaction().commit();
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	} 
	finally 
	{
		closeEntityManager();
	}
    return list;
}



public List<Objective> getStackObjectives(int stack_id) 
{
	List<Objective> list=new ArrayList<Objective>();
	try 
	{
		em=getEntityManager();
		em.getTransaction().begin();
		Query query=em.createQuery("from Objective where stack_id='"+stack_id+"' and module_id is null");
		list=(List<Objective>)query.getResultList();
		em.getTransaction().commit();
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	} 
	finally 
	{
		closeEntityManager();
	}
    return list;
}



public void addObjectiveToModule(int module,int objective) 
{
	
	
	try 
	{
		em=getEntityManager();
		em.getTransaction().begin();
		Objective o=em.find(Objective.class,objective);
		Module m=em.getReference(Module.class,module);
		o.setModule(m);
		em.getTransaction().commit();
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	} 
	finally 
	{
		closeEntityManager();
	}

}





public void removeObjective(int objective_id) 
{
	try 
	{
		em=getEntityManager();
		em.getTransaction().begin();
		Objective o=em.find(Objective.class,objective_id);
		o.setModule(null);
		em.getTransaction().commit();
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	} 
	finally 
	{
		closeEntityManager();
	}
}



public int getStack_id(String stack) 
{
	List<Stack> list=new ArrayList<Stack>();  
	int i=0;
	try 
	{
		em=getEntityManager();
		em.getTransaction().begin();
		Query query=em.createQuery("from Stack where name='"+stack+"'");
		Stack s=(Stack)query.getSingleResult();
		em.getTransaction().commit();
		
			i=s.getId();
		
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	} 
	finally 
	{
		closeEntityManager();
	}
	return i;
}



public int getModule_id(String module) 
{
	List<Module> list=new ArrayList<Module>();  
	int i=0;
	try 
	{
		em=getEntityManager();
		em.getTransaction().begin();
		Query query=em.createQuery("from Module where name='"+module+"'");
		Module m=(Module)query.getSingleResult();
		em.getTransaction().commit();
		
			i=m.getId();
		System.out.println(i);
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	} 
	finally 
	{
		closeEntityManager();
	}
	return i;
}



public int getObjective_id(String objective) 
{ 
	int i=0;
	try 
	{
		em=getEntityManager();
		em.getTransaction().begin();
		Query query=em.createQuery("from Objective where name='"+objective+"'");
		Objective o=(Objective)query.getSingleResult();
		em.getTransaction().commit();
		
		
			i=o.getId();
		
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	} 
	finally 
	{
		closeEntityManager();
	}
	return i;
}

//Methods to create table initially for test

public void insertCourse(Course c) 
{
	 try
     {
     	em=getEntityManager();
			em.getTransaction().begin();
         em.persist(c);
         em.getTransaction().commit();
     }
     catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			closeEntityManager();
		}
	
}



public void insertModule(Module m) 
{
	 try
     {
     	em=getEntityManager();
			em.getTransaction().begin();
         em.persist(m);
         em.getTransaction().commit();
     }
     catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			closeEntityManager();
		}
	
}



public void insertStack(Stack s) 
{
	 try
     {
     	em=getEntityManager();
			em.getTransaction().begin();
         em.persist(s);
         em.getTransaction().commit();
     }
     catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			closeEntityManager();
		}
	
}



public void insertObj(Objective o1) 
{
	 try
     {
     	em=getEntityManager();
			em.getTransaction().begin();
         em.persist(o1);
         em.getTransaction().commit();
     }
     catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			closeEntityManager();
		}
	
}



public Course getCourse(int course_id) 
{
	Course c=null;
	 try
     {
     	em=getEntityManager();
		em.getTransaction().begin();
        c=em.find(Course.class,course_id);
        em.getTransaction().commit();
     }
     catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			closeEntityManager();
		}
	 return c;

}




		
}


